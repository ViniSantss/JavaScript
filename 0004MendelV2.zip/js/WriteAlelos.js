
Alelos1 = ["b","B"]
AlelosCount1 = 2;//!Redundante
AlelosName1=["Baixo","Alto"]
Alelos2 = ["c","C"]
AlelosCount2 = 2;//!Redundante
AlelosName2=["Curto","Longo"]
WriteAlelos()
function CalcNames(){
    for(var k=1;k<=2;k++){
        for(var j=0;j<eval('AlelosCount'+k);j++){
            //console.log(AlelosName1,AlelosName2)
            //console.log(eval('Alelos'+k+'['+j+']'))//=
            //console.log(eval('document.getElementById("Alelo'+j+'G'+k+'").Value'))
            //console.log('Alelo'+j+'G'+k)
            if(document.getElementById("Alelo"+j+"G"+k).value !=""){
            var TempValue = document.getElementById("Alelo"+j+"G"+k).value[0]
            }else{
                TempValue = "U"
            }
            var TempValue2 = document.getElementById("Alelo"+j+"G"+k).value
            eval('AlelosName'+k+'['+j+']="'+TempValue2+'"')
            if(j==0){
                TempValue = TempValue.toLowerCase()
                eval('Alelos'+k+'['+j+']="'+TempValue+'"')
                }else if(eval('AlelosCount'+k)<=2){
                    eval('Alelos'+k+'['+j+']=Alelos'+k+'['+0+'].toUpperCase()')
                }else{

                    
                    eval('Alelos'+k+'['+j+']=Alelos'+k+'['+0+'].toUpperCase()+microLetter(TempValue.toUpperCase())')
                }
        }
    }
}


function WriteAlelos(){
    var base="";
    for(var j=1;j<=2;j++){
        switch(j){
            case 1: base+='Gameta1:<br>';break;
            case 2: base+='Gamate2:<br>';
        }
        base+='<div class="row">'
        
 for(var i=0;i<eval('AlelosCount'+j);i++){

base+='<div class="col-12">'
base+='<div class="input-group flex-nowrap">'
base+=    '<span class="input-group-text" id="addon-wrapping">'
switch(i){
    case 0: base+='Alelo Recessivo ::';break;
    case 1: base+='Alelo Dominante 1:';break;
    default: base+='Alelo Dominante '+(i)+':';break;
}
base+=    '</span><input type="text" class="form-control" aria-label="Username" aria-describedby="addon-wrapping" id="Alelo'+i+'G'+j+'" value="'+eval('AlelosName'+j+'[i]')+'"></div></div>'




}
base+='<div class="col-4"><button type="button" onclick="AddAlelo('+j+',(+1))" class="btn btn-outline-success">+Alelos</button>'

if(eval('AlelosCount'+j)>2){
    base+='<button type="button" onclick="AddAlelo('+j+',(-1))" class="btn btn-outline-danger">-Alelos</button>'
}
base+='</div></div></div><br>'
}
base+='<div class="d-grid gap-2 col-3 mx-auto"><button class="btn btn-primary" type="button" onclick="WriteOptions()">Pronto</button></div>   '
document.getElementById("Alelos").innerHTML=base

}
function AddAlelo(int1,int2){
    eval("AlelosCount"+int1+'+='+int2)
    if(int2>0){
    eval("AlelosName"+int1+'['+'AlelosCount'+(int1)+'-1]='+'""')
    }
    WriteAlelos()

}