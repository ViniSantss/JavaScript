function WriteOptions(){
    CalcNames()
    
var base="";
base+='<div class="row">'
    for(var i=1;i<=8;i++){
        if(i==1){base+='<p>Pai:</p>'}
        if(i==5){base+='<p>Mãe:</p>'}
        base+='<div class="col-2"><select id="gene'+i+'" class="form-select" aria-label="Default select example">'
        if((i<=2)||(i>=5 && i<=6) ){
            for(var j=0;j<AlelosCount1;j++){
                base+='<option>'+Alelos1[j]+'</option>'
            }
}else{
    for(var j=0;j<AlelosCount2;j++){
        base+='<option>'+Alelos2[j]+'</option>'
    }

}        
base+='</select></div>'
}
base+='</div><br><div class="d-grid gap-2 col-5 mx-auto"><button class="btn btn-primary" type="button" onclick="ButtonClick()">Pronto</button></div>   '

console.log(base)
document.getElementById("Options").innerHTML=base

}
