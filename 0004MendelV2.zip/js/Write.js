function WriteArray(Obj, Div){
    console.log(Obj)
var base="";
    for(var i=0;i<Obj.length;i++){
        base+='<div class="row">'
        for(var j=0;j<Obj[i].length;j++){
base+='<div class="cell">'+Obj[i][j]+' <span class="tooltiptext">'+(1+i)+"x"+(1+j)+'</span></div>'
        }
        base+='</div>'
}
document.getElementById(Div).innerHTML=base

}
